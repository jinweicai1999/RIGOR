"""Read-only, network-free call-path check for reviewer 2 comment 3.

Executes the submitted method bodies with stubbed PubMed results to verify
whether changing P1 output can affect the batch-ranking path. This is a
branch-reachability test, not an empirical PubMed stability experiment.
"""

import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import pandas as pd


ROOT = Path('/Users/jinweicai/Project/RIGOR/1013RIGOR改稿/RIGOR')
LIT = ROOT / 'src/agents/literature_agent.py'
BATCH = ROOT / 'src/utils/protein_batch_analysis.py'


def method(path, class_name, method_name):
    module = ast.parse(path.read_text(encoding='utf-8'))
    cls = next(n for n in module.body if isinstance(n, ast.ClassDef) and n.name == class_name)
    fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == method_name)
    return fn


search = method(LIT, 'LiteratureAgent', '_search_target_gene_literature')
boost = method(BATCH, 'ProteinBatchAnalyzer', '_collect_literature_boost')
rank = method(BATCH, 'ProteinBatchAnalyzer', '_build_rank_df')

calls = [n for n in ast.walk(boost) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == '_search_target_gene_literature']
assert len(calls) == 1
arg = next(kw.value for kw in calls[0].keywords if kw.arg == 'use_symbol_search')
assert isinstance(arg, ast.Constant) and arg.value is True

scope = {'pd': pd}
future = ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0)
isolated = ast.fix_missing_locations(ast.Module(body=[future, search, boost, rank], type_ignores=[]))
exec(compile(isolated, str(ROOT), 'exec'), scope)


class FakeLiterature:
    def __init__(self, p1_terms):
        self.p1_terms = p1_terms
        self.p1_calls = 0
        self.queries = []

    def _txt(self, _zh, en):
        return en

    def _extract_protein_keywords_with_llm(self, _note):
        self.p1_calls += 1
        return self.p1_terms

    def _fallback_terms_from_symbol_and_note(self, gene_info):
        return [gene_info['Primary_Symbol']]

    def search_pubmed_ids(self, query, retmax=8, sort='relevance'):
        self.queries.append(query)
        if 'GENE_A' in query:
            return ['1001', '1002', '1003']
        if 'GENE_B' in query:
            return ['2001', '2002']
        if 'alpha P1' in query:
            return ['3001']
        if 'beta P1' in query:
            return ['4001', '4002', '4003', '4004']
        return []


gene_info = {
    'GENE_A': {'Primary_Symbol': 'GENE_A', 'Synonyms': [], 'Description': 'annotated protein A'},
    'GENE_B': {'Primary_Symbol': 'GENE_B', 'Synonyms': [], 'Description': 'annotated protein B'},
}


def run_batch(p1_terms):
    literature = FakeLiterature(p1_terms)
    literature._search_target_gene_literature = scope['_search_target_gene_literature'].__get__(literature)
    analyzer = SimpleNamespace(
        enable_literature=True,
        config=SimpleNamespace(top_per_scenario=10),
        annotator=SimpleNamespace(query=lambda gene_id: dict(gene_info[gene_id])),
        lit_agent=literature,
        _scenario_scores_from_evidence=lambda info, **kwargs: {'stress_defense': 50},
    )
    rows = [
        {'gene_id': 'GENE_A', 'base_score': 50, 'main_scenario': 'stress_defense', 'literature_boost_score': 0, 'pmids': [], 'partner_genes': [], 'traits': []},
        {'gene_id': 'GENE_B', 'base_score': 49, 'main_scenario': 'stress_defense', 'literature_boost_score': 0, 'pmids': [], 'partner_genes': [], 'traits': []},
    ]
    scope['_collect_literature_boost'](analyzer, rows)
    ranked = scope['_build_rank_df'](analyzer, rows)
    return {
        'p1_calls': literature.p1_calls,
        'queries': literature.queries,
        'ranked': ranked[['gene_id', 'literature_boost_score', 'total_score', 'rank']].to_dict('records'),
    }


a = run_batch(['alpha P1'])
b = run_batch(['beta P1'])
assert a == b
assert a['p1_calls'] == b['p1_calls'] == 0

# Positive control: the other branch really does invoke the P1 extractor.
positive = FakeLiterature(['alpha P1'])
scope['_search_target_gene_literature'](positive, dict(gene_info['GENE_A']), use_symbol_search=False)
assert positive.p1_calls == 1

result = {
    'scope': 'current submitted source; synthetic fixture and stubbed PubMed; no API/network calls',
    'batch_call_argument': 'use_symbol_search=True',
    'batch_call_line': calls[0].lineno,
    'p1_calls_in_batch_both_variants': [a['p1_calls'], b['p1_calls']],
    'p1_calls_in_nonbatch_positive_control': positive.p1_calls,
    'batch_outputs_identical_across_p1_variants': a == b,
    'batch_ranked_fixture': a['ranked'],
    'source_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [LIT, BATCH]},
    'interpretation': 'P1 output has no route to literature boost or ranking in this batch call path. This does not quantify changes from live PubMed records or other upstream inputs.',
}
out = Path('/private/tmp/R2C3_batch_P1_call_path_audit.json')
out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
