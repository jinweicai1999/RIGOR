"""Independent replay of the archived text-alignment scoring rule; no API calls."""
from collections import Counter
import csv
import math
from pathlib import Path
import re


HERE = Path(__file__).resolve().parent
FULL_FILES = ('p2_homology_inference.md','p3_coexpression_inference.md','p4_epigenomic_inference.md','p5_integrated_gene_report.md','p7_gwas_assessment.md')
MODULES = (('M1','M1 Core function (30%)',.30),('M2','M2 Network/pathway (25%)',.25),('M3','M3 Expression/regulation (20%)',.20),('M4','M4 Phenotype/breeding (15%)',.15))
CALIBRATION = re.compile(r'\b(?:uncertain|uncertainty|hypothes|candidate|putative|suggest|may|might|could|requires? validation|future validation|experimental validation|confidence|limitation|caution)\b',re.I)
TOKEN = re.compile(r'(?u)\b\w\w+\b')

def features(text,analyzer):
    text=text.lower()
    if analyzer=='word':
        words=TOKEN.findall(text)
        return Counter(words+[' '.join(p) for p in zip(words,words[1:])])
    out=Counter()
    for word in re.sub(r'\s\s+',' ',text).split():
        padded=' '+word+' '
        for n in (3,4,5):out.update(padded[i:i+n] for i in range(max(0,len(padded)-n+1)))
    return out

def vectors(corpus,analyzer):
    counts=[features(s,analyzer) for s in corpus];df=Counter();n=len(corpus)
    for doc in counts:df.update(doc.keys())
    idf={term:math.log((1+n)/(1+freq))+1 for term,freq in df.items()}
    result=[]
    for doc in counts:
        vec={term:(1+math.log(count))*idf[term] for term,count in doc.items()}
        norm=math.sqrt(sum(x*x for x in vec.values()))
        result.append({term:x/norm for term,x in vec.items()} if norm else {})
    return result

def cosine(a,b):
    if len(a)>len(b):a,b=b,a
    return sum(value*b.get(term,0.) for term,value in a.items())

def rank_matrix(outputs,gold):
    corpus=outputs+gold;n=len(outputs);w=vectors(corpus,'word');c=vectors(corpus,'char_wb')
    ranks=[];sims=[]
    for i in range(n):
        sim=[.5*cosine(w[i],w[n+j])+.5*cosine(c[i],c[n+j]) for j in range(n)]
        order=sorted(range(n),key=lambda j:sim[j]);row=[None]*n
        for rank,j in enumerate(order):row[j]=100*rank/(n-1)
        ranks.append(row);sims.append(sim)
    return ranks,sims

def load_records():
    with (HERE / 'reference_texts.csv').open(encoding='utf-8-sig') as f:
        records=list(csv.DictReader(f))
    records.sort(key=lambda x:x['Blind ID'])
    assert len(records)==26
    return records

def load_outputs(records,condition):
    import zipfile
    outputs=[]
    with zipfile.ZipFile(HERE/'model_outputs_and_api338.zip') as z:
        for row in records:
            bid=row['Blind ID'];folder='normalized_outputs/'+condition
            if condition=='full_rigor':names=[folder+'/'+bid+'/'+x for x in FULL_FILES]
            elif condition=='deterministic_no_llm':names=[folder+'/'+bid+'.md']
            elif condition=='pre_cutoff_literature_only':names=[folder+'/'+bid+'/literature_only.md']
            else:names=[folder+'/'+bid+'/'+condition+'.md']
            outputs.append('\n\n'.join(z.read(n).decode('utf-8',errors='replace') for n in names))
    return outputs

def compute(records,condition):
    outputs=load_outputs(records,condition);module_scores={};module_sims={}
    for key,column,_ in MODULES:
        rank,sim=rank_matrix(outputs,[str(row.get(column) or '') for row in records])
        module_scores[key]=[rank[i][i] for i in range(26)]
        module_sims[key]=[sim[i][i] for i in range(26)]
    m5=[100 if CALIBRATION.search(s) else 0 for s in outputs]
    scores=[sum(weight*module_scores[key][i] for key,_,weight in MODULES)+.1*m5[i] for i in range(26)]
    return scores,module_scores,module_sims,m5

def exact_signed_rank_greater(differences):
    pairs=sorted((round(abs(d),9),1 if d>0 else -1) for d in differences if abs(d)>1e-9)
    ranks=[];i=0
    while i<len(pairs):
        j=i+1
        while j<len(pairs) and pairs[j][0]==pairs[i][0]:j+=1
        rank=(i+1+j)/2
        ranks.extend((int(round(2*rank)),sign) for _,sign in pairs[i:j]);i=j
    observed=sum(rank for rank,sign in ranks if sign>0);dp=Counter({0:1})
    for rank,_ in ranks:
        next_dp=Counter(dp)
        for total,count in dp.items():next_dp[total+rank]+=count
        dp=next_dp
    return sum(count for total,count in dp.items() if total>=observed)/(2**len(ranks)),len(ranks),observed/2

def bh_adjust(values):
    n=len(values);order=sorted(range(n),key=lambda i:values[i]);out=[0]*n;minimum=1.
    for pos in range(n-1,-1,-1):
        index=order[pos];minimum=min(minimum,values[index]*n/(pos+1));out[index]=minimum
    return out

def main():
    import json
    records=load_records()
    with (HERE/'per_gene_scores.csv').open(encoding='utf-8-sig') as f:
        expected={(r['condition'],r['benchmark_id']):r for r in csv.DictReader(f)}
    conditions=['full_rigor','annotation_go_interpro','pre_cutoff_literature_only','deterministic_no_llm']
    differences=[];means={};verified=0
    for condition in conditions:
        scores,modules,sims,m5=compute(records,condition)
        means[condition]=sum(scores)/26
        for i,row in enumerate(records):
            old=expected[(condition,row['Benchmark ID'])]
            values={**{k:modules[k][i] for k in modules},'M5':m5[i],'composite_score':scores[i]}
            for key,value in values.items():
                if abs(value-float(old[key]))>1e-4:differences.append([condition,row['Benchmark ID'],key])
            verified+=1
    print(json.dumps({'verified_rows':verified,'component_or_score_mismatches':len(differences),'means':means},indent=2))
    if differences:raise RuntimeError(differences[:5])

if __name__=='__main__':main()
