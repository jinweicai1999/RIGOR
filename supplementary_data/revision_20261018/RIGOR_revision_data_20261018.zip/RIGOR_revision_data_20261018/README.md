# RIGOR revision data, 2026-10-18

This package contains existing archived results and their audit/plotting materials. It does not represent new model runs or new wet-lab experiments. It is prepared locally and has not been uploaded by this packaging step.

## Contents

- `01_baselines`: 26 genes x four original conditions (104 rows), three paired baseline tests, verbatim reference-text fields, the OsCML17 worked example, and the original archive containing 338 API responses and normalized outputs. Original full-RIGOR mean: 80.82.
- `02_ablation`: the separate standardized-output ablation summaries and existing paired/sensitivity tests. Its full-evidence reference mean is 79.85, not 80.82.
- `03_same_evidence_comparison`: the C2DP40 structured-versus-synthesized display and its limitations; run 001 was chosen by index.
- `04_stability`: the original 200-run/800-call archive, call manifest, run-level citations, and 19,900 pairwise citation-set comparisons.
- `05_free_recall`: 26 current-model responses/adjudications and metadata; 0/26 direct matches to the specific held-out 2026 findings does not exclude parametric memory.
- `06_route_audit`: the existing network-free P1 call-path check, using fixtures and stubbed PubMed responses rather than live repeated retrieval.
- `07_figures`: current Figures R1 and R2; Figure R2 is the single Jaccard-distribution plot (the redundant proportion panel was removed).
- `08_api_manifest`: the original campaign's 338-call inventory.
- `09_provenance`: per-file source/version/access-date fields and SHA-256 records, trait-specific GWAS backgrounds and the independently verified official RGAP expression-file match.

## Provenance boundaries

Source acquisition dates are author-reported as 2026-04-10 for annotation, expression, co-expression and promoter-epigenomic resources, and 2026-04-16 for the original GWAS association files. They were not independently reconstructed from download logs. Local creation/copy timestamps and the 2026-04-30 GWAS-index build date are recorded separately. The three core RAP-DB GFFs exactly match the official 2025-03-19 release; the expression workbook matches the official RGAP download. The release-availability lookup distinguishes actual archive releases, official website updates and resource-paper dates. These public resource dates precede the reported downloads, but do not identify every processed-file version. RiceVarMap catalog candidates for the 10 GWAS traits were identified; sampled local P-values differ, so no verified file-level source-population assignment is asserted. Current-copy hashes alone do not prove identity with all historical benchmark inputs.

The 26-gene prior-literature/selection audit and the wet-lab documentation/statistical reanalysis remain separate unfinished tasks; they are not represented as completed here. Scoring values measure retrospective evidence alignment, not genome-wide biological prediction accuracy.

## Reproduction and checks

The original scoring script is retained unchanged, including its historical paths. `01_baselines/reproduce_alignment.py` is the portable replay entry point: it reads the packaged reference CSV and archived normalized outputs, uses only the Python standard library, and compares all 104 recomputed scores with the included per-gene table. It does not call a model API.

`MANIFEST_SHA256.csv` covers every packaged file except the manifest itself. The accompanying package audit records row counts, archive integrity and a limited credential-pattern scan. It does not prove the scientific validity of every generated statement. No credentials or local `.env` files are intentionally included.
