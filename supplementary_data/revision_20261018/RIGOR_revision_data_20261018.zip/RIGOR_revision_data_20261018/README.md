# RIGOR revision data, 2026-10-18

This package contains existing archived results and their audit/plotting materials. It does not represent new model runs or new wet-lab experiments. It is prepared locally and has not been uploaded by this packaging step.

## Contents

- `01_baselines`: 26 genes x four original conditions (104 rows), three paired baseline tests, verbatim reference-text fields, the OsCML17 worked example, and the original archive containing 338 API responses and normalized outputs. Original full-RIGOR mean: 80.82.
- `02_ablation`: the separate standardized-output ablation summaries and existing paired/sensitivity tests. Its full-evidence reference mean is 79.85, not 80.82.
- `03_same_evidence_comparison`: the C2DP40 structured-versus-synthesized display and its limitations; run 001 was chosen by index.
- `04_stability`: the original 200-run/800-call archive, call manifest, run-level citations, and 19,900 pairwise citation-set comparisons.
- `05_free_recall`: 26 current-model responses/adjudications and metadata; 0/26 direct matches to the specific held-out 2026 findings does not exclude parametric memory.
- `06_route_audit`: the existing network-free P1 call-path check, using fixtures and stubbed PubMed responses rather than live repeated retrieval.
- `07_figures`: current Figures R1 and R2; Figure R2 is the single Jaccard-distribution plot (the redundant proportion panel was removed).
- `08_api_manifest`: the original campaign's 338-call inventory.
- `09_provenance`: per-file source/version/access-date fields and SHA-256 records, trait-specific GWAS backgrounds and the independently verified official RGAP expression-file match.

## Provenance boundaries

The original download/access dates of the historical local resource bundle were not retained in the available records. The verification date 2026-10-18 is not substituted for those original dates. Embedded XLSX creation dates and filesystem times are not download dates. The expression workbook's SHA-256 exactly matches the official RGAP Release 7 download. Some other resources retain only genome-build, version-name or accession labels; exact upstream releases are explicitly marked unresolved. The local GWAS index build is recorded, but the per-trait mapping to the cited source populations was not recovered. File hashes identify the retained copies without proving that all of them were the exact historical files used in every benchmark run.

The 26-gene prior-literature/selection audit and the wet-lab documentation/statistical reanalysis remain separate unfinished tasks; they are not represented as completed here. Scoring values measure retrospective evidence alignment, not genome-wide biological prediction accuracy.

## Reproduction and checks

The original scoring script is retained unchanged, including its historical paths. `01_baselines/reproduce_alignment.py` is the portable replay entry point: it reads the packaged reference CSV and archived normalized outputs, uses only the Python standard library, and compares all 104 recomputed scores with the included per-gene table. It does not call a model API.

`MANIFEST_SHA256.csv` covers every packaged file except the manifest itself. The accompanying package audit records row counts, archive integrity and a limited credential-pattern scan. It does not prove the scientific validity of every generated statement. No credentials or local `.env` files are intentionally included.
