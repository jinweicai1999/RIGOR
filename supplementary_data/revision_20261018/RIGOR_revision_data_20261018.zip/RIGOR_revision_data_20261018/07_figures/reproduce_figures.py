"""New response figures drawn from existing archived results; no API calls."""
from __future__ import annotations
import csv
import io
import json
from pathlib import Path
from zipfile import ZipFile
import numpy as np
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color
import pypdfium2 as pdfium

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent
OUT = HERE
OUT.mkdir(parents=True, exist_ok=True)
COLORS = ['#0072B2', '#E69F00', '#009E73', '#CC79A7']

def rows(path):
    with path.open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))

def text(c, x, y, s, size=10, bold=False, color='#253442', align='left'):
    c.setFont('Helvetica-Bold' if bold else 'Helvetica',size)
    c.setFillColor(HexColor(color))
    getattr(c, {'left':'drawString','center':'drawCentredString','right':'drawRightString'}[align])(x,y,str(s))

def line(c,x1,y1,x2,y2,color='#CAD1D8',width=.6):
    c.setStrokeColor(HexColor(color));c.setLineWidth(width);c.line(x1,y1,x2,y2)

def export_png(pdf):
    doc=pdfium.PdfDocument(str(pdf));doc[0].render(scale=3).to_pil().save(pdf.with_suffix('.png'))

data=rows(SOURCE/'01_baselines/per_gene_scores.csv')
tests=rows(SOURCE/'01_baselines/paired_baseline_tests.csv')
conditions=['full_rigor','annotation_go_interpro','pre_cutoff_literature_only','deterministic_no_llm']
labels=[['Full','RIGOR'],['Annotation /','GO / InterPro'],['Pre-cutoff','literature'],['Deterministic','no-LLM']]
by_condition={key:sorted([r for r in data if r['condition']==key],key=lambda r:r['benchmark_id']) for key in conditions}
assert all(len(v)==26 for v in by_condition.values())
pdf=OUT/'Figure_R1_原基准与三种基线对照_新增绘图.pdf'
c=canvas.Canvas(str(pdf),pagesize=(540,710))
text(c,35,682,'26-gene benchmark: full RIGOR and baselines',14,True)
text(c,35,660,'Existing paired outputs; black horizontal marks indicate means.',10,color='#5A6978')
for panel,(field,title) in enumerate([('composite_score','A  Five-dimension evidence alignment'),('score_without_M5','B  Sensitivity analysis excluding M5')]):
    left=60;bottom=409 if panel==0 else 82;width=435;height=190
    text(c,left-18,632 if panel==0 else 305,title,13,True)
    for tick in range(0,101,20):
        yy=bottom+height*tick/100
        line(c,left,yy,left+width,yy,'#E6EAF0',.6)
        text(c,left-10,yy-3,tick,10,align='right')
    line(c,left,bottom,left+width,bottom,'#667684',.8)
    line(c,left,bottom,left,bottom+height,'#667684',.8)
    c.saveState();c.translate(left-43,bottom+height/2);c.rotate(90)
    text(c,0,0,'Evidence-alignment score',10,align='center');c.restoreState()
    xs=[left+45+j*(width-90)/3 for j in range(4)]
    for i in range(26):
        jitter=((i*17)%29-14)*.24
        vals=[float(by_condition[k][i][field]) for k in conditions]
        for j in range(3):line(c,xs[j]+jitter,bottom+height*vals[j]/100,xs[j+1]+jitter,bottom+height*vals[j+1]/100,'#D4DADF',.35)
    for j,key in enumerate(conditions):
        vals=[float(r[field]) for r in by_condition[key]]
        for i,val in enumerate(vals):
            xx=xs[j]+((i*17)%29-14)*.24; yy=bottom+height*val/100
            c.setFillColor(HexColor(COLORS[j]));c.circle(xx,yy,1.85,fill=1,stroke=0)
        mean=float(np.mean(vals));yy=bottom+height*mean/100
        line(c,xs[j]-10,yy,xs[j]+10,yy,'#152A38',2.2)
        text(c,xs[j],bottom+height+10,f'{mean:.2f}',10,True,align='center')
        for k,part in enumerate(labels[j]):text(c,xs[j],bottom-18-12*k,part,10,align='center')
    qkey='bh_fdr_across_3_baselines' if panel==0 else 'bh_fdr_without_M5_across_3_baselines'
    q=[float(t[qkey]) for t in tests]
    text(c,left,bottom-57,'BH-FDR vs full:  '+', '.join(f'{x:.4g}' for x in q),10)
    text(c,left,bottom-73,'Order: annotation, literature, no-LLM; BH over three contrasts.',8,color='#5A6978')
c.save();export_png(pdf)

records=rows(SOURCE/'04_stability/run_200_citation_records.csv')
assert len(records)==200
sets=[set(r['cited_pmids'].split(';'))-set(['']) for r in records]
pair_rows=[]
for i,a in enumerate(sets):
    for j in range(i+1,len(sets)):
        b=sets[j];v=len(a&b)/len(a|b) if a|b else 1.
        pair_rows.append(dict(run_i=i+1,run_j=j+1,jaccard=v,identical_set=int(a==b)))
assert len(pair_rows)==19900
same=sum(r['identical_set'] for r in pair_rows);different=len(pair_rows)-same
mean=float(np.mean([r['jaccard'] for r in pair_rows]))
assert different==19785 and round(mean,3)==.624
with (OUT/'Figure_R2_19900对引用集合比较.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(pair_rows[0]));w.writeheader();w.writerows(pair_rows)
pdf=OUT/'Figure_R2_引用PMID集合波动_新增绘图.pdf'
c=canvas.Canvas(str(pdf),pagesize=(540,420))
text(c,35,392,'Cited-PMID set similarity under fixed evidence',14,True)
text(c,35,371,'C2DP40: 200 synthesis runs; 19,900 output pairs.',10,color='#5A6978')
left=65;bottom=75;width=430;height=260
hist,edges=np.histogram([r['jaccard'] for r in pair_rows],bins=np.linspace(0,1,21));maxy=int(max(hist)*1.15)
for tick in [0,1000,2000,3000,4000,5000]:
    if tick>maxy:continue
    yy=bottom+height*tick/maxy;line(c,left,yy,left+width,yy,'#E6EAF0',.6);text(c,left-8,yy-3,tick,10,align='right')
for j,count in enumerate(hist):
    xx=left+width*edges[j];bw=width*(edges[j+1]-edges[j]);bh=height*count/maxy
    c.setFillColor(HexColor('#56A3C9'));c.rect(xx+.6,bottom,bw-1.2,bh,fill=1,stroke=0)
line(c,left,bottom,left+width,bottom,'#667684',.8);line(c,left,bottom,left,bottom+height,'#667684',.8)
c.saveState();c.translate(left-43,bottom+height/2);c.rotate(90)
text(c,0,0,'Output pairs',10,align='center');c.restoreState()
for tick in np.linspace(0,1,6):text(c,left+width*tick,bottom-17,f'{tick:.1f}',10,align='center')
xx=left+width*mean;c.setDash(4,3);line(c,xx,bottom,xx,bottom+height,'#152A38',1.3);c.setDash()
text(c,left+width/2,bottom-37,'Pairwise cited-PMID Jaccard similarity',10,align='center')
text(c,left+12,bottom+height-20,f'Mean = {mean:.3f}',12,True)
text(c,35,12,'Fixed-evidence synthesis; this distribution measures citation-set overlap.',8,color='#5A6978')
c.save();export_png(pdf)
(OUT/'新图核对记录.json').write_text(json.dumps(dict(genes_per_condition=26,run_pairs=19900,
    pairs_different=different,pairs_identical=same,mean_jaccard=mean,
    new_model_runs=0,new_api_calls=0),ensure_ascii=False,indent=2))
print(json.dumps(dict(output=str(OUT),new_figures=2,pairs_different=different,mean_jaccard=mean),ensure_ascii=False))
